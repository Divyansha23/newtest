import 'dart:io';
import 'package:dart_appwrite/dart_appwrite.dart';

// Future<dynamic> main(final context) async {
//   return context.res.json({
//     'motto': 'Build like a team of hundreds_',
//     'learn': 'https://appwrite.io/docs',
//     'connect': 'https://appwrite.io/discord',
//     'getInspired': 'https://builtwith.appwrite.io',
//   });
// }

Future<dynamic> main(final context) async {
  try {
    // Initialize Appwrite client
    Client client = Client();
    client
        .setEndpoint(
            Platform.environment['APPWRITE_FUNCTION_API_ENDPOINT'] ?? '')
        .setProject(Platform.environment['APPWRITE_FUNCTION_PROJECT_ID'] ?? '')
        .setKey(Platform.environment['APPWRITE_FUNCTION_API_KEY'] ?? '');

    // Get the request method and path
    final method = context.req.method;
    final path = context.req.path;

    context.log('Received $method request to $path');

    // Handle GET requests (OAuth callback)
    if (method == 'GET') {
      // Get query parameters from the request
      final queryParams = context.req.query;
      final code = queryParams['code'];
      final state = queryParams['state'];
      final error = queryParams['error'];

      if (error != null) {
        context.log('OAuth error: $error');
        return context.res.json({
          'success': false,
          'error': 'OAuth authentication failed',
          'details': error
        }, 400);
      }

      if (code != null) {
        context.log(
            'OAuth callback received with code: ${code.substring(0, 10)}...');

        // Here you would typically exchange the code for tokens
        // and create/update the user session

        return context.res.json({
          'success': true,
          'message': 'OAuth callback processed successfully',
          'code': code,
          'state': state
        });
      }

      return context.res.json(
          {'success': false, 'error': 'No authorization code received'}, 400);
    }

    // Handle other HTTP methods
    return context.res
        .json({'success': false, 'error': 'Method not allowed'}, 405);
  } catch (e) {
    context.error('Function error: $e');
    return context.res.json({
      'success': false,
      'error': 'Internal server error',
      'details': e.toString()
    }, 500);
  }
}
